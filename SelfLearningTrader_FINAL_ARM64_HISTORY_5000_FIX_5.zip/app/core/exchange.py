import json
from urllib.parse import urlencode
from urllib.request import Request, urlopen
import ssl

try:
    import certifi
except ImportError:
    certifi = None

BASE = "https://api.kucoin.com"


class KuCoin:
    def __init__(self, symbol, timeout=25):
        self.symbol = symbol
        self.timeout = timeout

    def _get(self, path, params):
        url = BASE + path
        if params:
            url += "?" + urlencode(params)

        request = Request(
            url,
            headers={
                "User-Agent": "SelfLearningTrader/1.0",
                "Accept": "application/json",
            },
        )

        if certifi is not None:
            context = ssl.create_default_context(cafile=certifi.where())
        else:
            context = ssl.create_default_context()

        with urlopen(request, timeout=self.timeout, context=context) as response:
            data = json.loads(response.read().decode("utf-8"))

        if data.get("code") not in (None, "200000"):
            raise RuntimeError(str(data))

        return data.get("data", data)

    def candles(self, tf, limit=300):
        """Fetch historical candles with time pagination.

        KuCoin returns at most 1500 klines per request.  A single request
        can therefore silently leave the app with only a small training
        sample.  We page backwards by endAt until the requested number of
        unique candles is collected.
        """
        wanted = max(1, int(limit))
        page_size = min(wanted, 1500)
        all_rows = []
        end_at = None
        seen = set()

        for _ in range((wanted + 1499) // 1500 + 2):
            params = {
                "symbol": self.symbol,
                "type": tf,
                "limit": page_size,
            }
            if end_at is not None:
                params["endAt"] = int(end_at)

            raw = self._get("/api/v1/market/candles", params)
            if not raw:
                break

            before = len(all_rows)
            oldest = None
            for r in raw:
                if len(r) < 7:
                    continue
                try:
                    ts = int(float(r[0]))
                    row = {
                        "time": ts,
                        "open": float(r[1]),
                        "close": float(r[2]),
                        "high": float(r[3]),
                        "low": float(r[4]),
                        "volume": float(r[5]),
                        "turnover": float(r[6]),
                    }
                except (TypeError, ValueError):
                    continue
                oldest = ts if oldest is None else min(oldest, ts)
                if ts not in seen:
                    seen.add(ts)
                    all_rows.append(row)

            if len(all_rows) >= wanted:
                break
            if oldest is None or len(all_rows) == before:
                break
            end_at = oldest - 1

        all_rows.sort(key=lambda x: x["time"])
        if len(all_rows) > wanted:
            all_rows = all_rows[-wanted:]
        if not all_rows:
            raise RuntimeError(f"KuCoin returned no candles for {tf}")
        return all_rows

    def orderbook_imbalance(self):
        raw = self._get(
            "/api/v1/market/orderbook/level2_20",
            {"symbol": self.symbol},
        )
        bids = sum(float(q) for _, q in raw.get("bids", []))
        asks = sum(float(q) for _, q in raw.get("asks", []))
        return (bids - asks) / (bids + asks + 1e-12)

    def current_market_metrics(self):
        try:
            imbalance = self.orderbook_imbalance()
        except Exception:
            imbalance = 0.0
        return {
            "book_imbalance": float(imbalance),
            "oi_change": 0.0,
            "funding": 0.0,
            "liquidation_bias": 0.0,
        }
